// "Source" websites (jinko scraper check karega) add/remove/list karne ke API

const express = require("express");
const router = express.Router();
const Source = require("../models/Source");
const { checkAllSources } = require("../scheduler");

// GET /api/sources -> saari added websites dikhao
router.get("/", async (req, res) => {
  const sources = await Source.find();
  res.json(sources);
});

// POST /api/sources -> nayi website add karo
// Body: { "name": "SSC", "url": "https://ssc.nic.in" }
router.post("/", async (req, res) => {
  try {
    const { name, url, parserType } = req.body;
    const source = await Source.create({ name, url, parserType });
    res.json(source);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE /api/sources/:id -> website hatao
router.delete("/:id", async (req, res) => {
  await Source.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

// POST /api/sources/check-now -> turant sab sources check karo (test ke liye)
router.post("/check-now", async (req, res) => {
  const io = req.app.get("io");
  await checkAllSources(io);
  res.json({ success: true, message: "Check chal raha hai, jaise hi naya job milega live dikh jayega" });
});

module.exports = router;
